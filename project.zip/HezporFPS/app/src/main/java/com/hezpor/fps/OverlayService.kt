package com.hezpor.fps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import kotlin.random.Random

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var lp: WindowManager.LayoutParams
    private var tv: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    private var cur = 270f
    private var frames = 0
    private var real = 0

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            real = frames * 2
            frames = 0
            update()
            h.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (tv == null) createOverlay()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("fps", "FPS", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "fps")
            .setContentTitle("Hezpor FPS đang chạy")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun createOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("fps", MODE_PRIVATE)

        val t = TextView(this)
        t.gravity = Gravity.CENTER
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)

        lp = WindowManager.LayoutParams(
            300, 120,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt("px", 40)
        lp.y = prefs.getInt("py", 120)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        t.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(t, lp)
                }
                MotionEvent.ACTION_UP -> {
                    prefs.edit().putInt("px", lp.x).putInt("py", lp.y).apply()
                }
            }
            true
        }

        wm.addView(t, lp)
        tv = t
        update()
        Choreographer.getInstance().postFrameCallback(frameCb)
        h.postDelayed(tick, 500)
    }

    private fun update() {
        val t = tv ?: return
        val mode = prefs.getString("mode", "fake")
        val circle = prefs.getString("shape", "square") == "circle"

        val v: Int
        if (mode == "real") {
            v = real
        } else {
            var lo = prefs.getInt("min", 240)
            var hi = prefs.getInt("max", 300)
            if (lo > hi) { val x = lo; lo = hi; hi = x }
            cur += Random.nextFloat() * 24f - 12f
            if (cur < lo) cur = lo + Random.nextFloat() * 4f
            if (cur > hi) cur = hi - Random.nextFloat() * 4f
            v = cur.toInt()
        }

        val d = resources.displayMetrics.density
        val w = prefs.getInt("w", 120)
        val hh = prefs.getInt("h", 40)
        lp.width = (w * d).toInt()
        lp.height = ((if (circle) w else hh) * d).toInt()

        val a = prefs.getInt("alpha", 70) * 255 / 100
        val bc = prefs.getInt("bc", Color.BLACK)
        val g = GradientDrawable()
        g.shape = if (circle) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
        g.cornerRadius = 20f * d
        g.setColor(Color.argb(a, Color.red(bc), Color.green(bc), Color.blue(bc)))
        t.background = g

        t.setTextColor(prefs.getInt("tc", Color.GREEN))
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.getInt("size", 22).toFloat())
        t.text = if (circle) "FPS\n$v" else "FPS: $v"
        wm.updateViewLayout(t, lp)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        tv?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        tv = null
        super.onDestroy()
    }
}
