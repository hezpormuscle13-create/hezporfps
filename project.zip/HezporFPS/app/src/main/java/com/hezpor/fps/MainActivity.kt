package com.hezpor.fps

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("fps", MODE_PRIVATE)

        val root = FrameLayout(this)
        val bg = ImageView(this)
        bg.setImageResource(R.drawable.bg)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(Color.parseColor("#A6000000"))
        panel.setPadding(dp(14), dp(14), dp(14), dp(14))

        val scroll = ScrollView(this)
        scroll.addView(panel)
        val sh = (resources.displayMetrics.heightPixels * 0.66).toInt()
        val slp = FrameLayout.LayoutParams(-1, sh, Gravity.BOTTOM)
        slp.setMargins(dp(10), 0, dp(10), dp(24))
        root.addView(scroll, slp)

        val title = label("HEZPOR FPS")
        title.gravity = Gravity.CENTER
        title.textSize = 18f
        panel.addView(title)

        // Chọn game
        panel.addView(label("Chọn game"))
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .sortedBy { it.first.lowercase() }
        val sp = Spinner(this)
        sp.setBackgroundColor(Color.WHITE)
        sp.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, apps.map { it.first }
        )
        val saved = prefs.getString("game", null)
        val idx = apps.indexOfFirst { it.second == saved }
        if (idx >= 0) sp.setSelection(idx)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("game", apps[pos].second).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        panel.addView(sp)

        addRadio(panel, "mode", "fake", listOf("FPS ảo" to "fake", "FPS thật" to "real"))
        addRadio(panel, "shape", "square", listOf("Hình vuông" to "square", "Hình tròn" to "circle"))
        addSeek(panel, "Thấp nhất (FPS ảo)", "min", 200, 300, 240)
        addSeek(panel, "Cao nhất (FPS ảo)", "max", 200, 300, 300)
        addColors(panel, "Màu số", "tc",
            intArrayOf(Color.GREEN, Color.RED, Color.YELLOW, Color.WHITE, Color.CYAN))
        addColors(panel, "Màu nền", "bc",
            intArrayOf(Color.BLACK, Color.WHITE, Color.BLUE, Color.RED, Color.DKGRAY))
        addSeek(panel, "Độ đậm nền %", "alpha", 0, 100, 70)
        addSeek(panel, "Cỡ số", "size", 10, 60, 22)
        addSeek(panel, "Chiều dài (hoặc kích thước tròn)", "w", 60, 360, 120)
        addSeek(panel, "Chiều cao (hình vuông)", "h", 24, 140, 40)

        panel.addView(button("CHƠI GAME (hiện FPS)", "#22C55E") {
            val pkg = prefs.getString("game", null)
            val li = if (pkg != null) packageManager.getLaunchIntentForPackage(pkg) else null
            if (li == null) {
                Toast.makeText(this, "Hãy chọn game", Toast.LENGTH_SHORT).show()
            } else if (startFps()) {
                startActivity(li)
            }
        })
        panel.addView(button("Chỉ bật FPS", "#3B82F6") { startFps() })
        panel.addView(button("Tắt FPS", "#EF4444") {
            stopService(Intent(this, OverlayService::class.java))
        })

        setContentView(root)
    }

    private fun startFps(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Hãy bật quyền hiển thị trên ứng dụng khác", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return false
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        return true
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.setPadding(0, dp(8), 0, dp(2))
        return tv
    }

    private fun button(t: String, color: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.parseColor(color))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, dp(10), 0, 0)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addRadio(p: LinearLayout, key: String, def: String, opts: List<Pair<String, String>>) {
        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.HORIZONTAL
        val cur = prefs.getString(key, def)
        for ((lab, v) in opts) {
            val rb = RadioButton(this)
            rb.text = lab
            rb.setTextColor(Color.WHITE)
            rb.id = View.generateViewId()
            rg.addView(rb)
            rb.isChecked = (v == cur)
            rb.setOnClickListener { prefs.edit().putString(key, v).apply() }
        }
        p.addView(rg)
    }

    private fun addSeek(p: LinearLayout, title: String, key: String, min: Int, max: Int, def: Int) {
        val cur = prefs.getInt(key, def)
        val tv = label("$title: $cur")
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                prefs.edit().putInt(key, v + min).apply()
                tv.text = "$title: ${v + min}"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        p.addView(tv)
        p.addView(sb)
    }

    private fun addColors(p: LinearLayout, title: String, key: String, cols: IntArray) {
        p.addView(label(title))
        val row = LinearLayout(this)
        for (c in cols) {
            val v = View(this)
            v.setBackgroundColor(c)
            val lp = LinearLayout.LayoutParams(dp(42), dp(32))
            lp.setMargins(0, dp(4), dp(8), dp(4))
            v.layoutParams = lp
            v.setOnClickListener { prefs.edit().putInt(key, c).apply() }
            row.addView(v)
        }
        p.addView(row)
    }
}
